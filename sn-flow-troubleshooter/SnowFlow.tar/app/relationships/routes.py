from flask import render_template, request, redirect, url_for, flash, jsonify
from app.relationships import bp
from app.extensions import db
from app.models.relationships import JoinModel
from sqlalchemy import inspect


@bp.route('/')
def index():
    inspector = inspect(db.engine)
    internal_tables = set(db.metadata.tables.keys()) | {'alembic_version'}
    sn_tables = [t for t in inspector.get_table_names() if t not in internal_tables]
    models = JoinModel.query.filter_by(is_archived=False).order_by(JoinModel.updated_at.desc()).all()
    return render_template('relationships/index.html', models=models, sn_tables=sn_tables)


@bp.route('/new', methods=['POST'])
def new_model():
    name = request.form.get('name', 'Untitled Model')
    description = request.form.get('description', '')
    model = JoinModel(name=name, description=description)
    db.session.add(model)
    db.session.commit()
    return redirect(url_for('relationships.canvas', model_id=model.id))


@bp.route('/canvas/<int:model_id>')
def canvas(model_id):
    model = JoinModel.query.get_or_404(model_id)
    inspector = inspect(db.engine)
    internal_tables = set(db.metadata.tables.keys()) | {'alembic_version'}
    sn_tables = [t for t in inspector.get_table_names() if t not in internal_tables]
    # Get columns for each table
    table_columns = {}
    for t in sn_tables:
        table_columns[t] = [c['name'] for c in inspector.get_columns(t)]
    return render_template('relationships/canvas.html', model=model, sn_tables=sn_tables, table_columns=table_columns)
