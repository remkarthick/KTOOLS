from flask import Blueprint

bp = Blueprint('relationships', __name__)

from app.relationships import routes
