from flask import Flask
from app.extensions import db, migrate
from config import config

def create_app(config_name='default'):
    app = Flask(__name__)
    app.config.from_object(config[config_name])

    db.init_app(app)
    migrate.init_app(app, db)

    # Import all models so Flask-Migrate sees them
    from app.models import (BaseModel, ServiceNowConnection,
                            SyncTableConfig, SyncJobLog,
                            JoinModel, CanvasNode, TableRelationship,
                            SavedFilter, SavedView)

    from app.main.routes import bp as main_bp
    app.register_blueprint(main_bp)

    from app.connections.routes import bp as connections_bp
    app.register_blueprint(connections_bp, url_prefix='/connections')

    from app.sync.routes import bp as sync_bp
    app.register_blueprint(sync_bp, url_prefix='/sync')

    from app.explorer.routes import bp as explorer_bp
    app.register_blueprint(explorer_bp, url_prefix='/explorer')

    from app.relationships.routes import bp as relationships_bp
    app.register_blueprint(relationships_bp, url_prefix='/relationships')

    from app.api import bp as api_bp
    app.register_blueprint(api_bp, url_prefix='/api/v1')

    return app
