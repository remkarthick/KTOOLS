from flask import render_template
from app.reports import bp
from app.extensions import db
from app.models.sync import SyncTableConfig, SyncJobLog
from app.models.relationships import JoinModel
from sqlalchemy import inspect, text


@bp.route('/')
def index():
    inspector = inspect(db.engine)
    internal_tables = set(db.metadata.tables.keys()) | {'alembic_version'}
    tables = [t for t in inspector.get_table_names() if t not in internal_tables]
    stats = []
    with db.engine.connect() as conn:
        for t in tables:
            count = conn.execute(text(f'SELECT COUNT(*) FROM "{t}"')).scalar()
            stats.append({'name': t, 'display': t, 'count': count})

    # Sync metrics
    total_syncs  = SyncJobLog.query.count()
    success_count = SyncJobLog.query.filter_by(status='SUCCESS').count()
    failed_count  = SyncJobLog.query.filter_by(status='FAILED').count()
    recent_logs   = SyncJobLog.query.order_by(SyncJobLog.start_time.desc()).limit(10).all()
    join_models = JoinModel.query.filter_by(is_archived=False).all()
    join_models_count = len(join_models)

    return render_template(
        'reports/index.html',
        stats=stats,
        total_syncs=total_syncs,
        success_count=success_count,
        failed_count=failed_count,
        recent_logs=recent_logs,
        join_models=join_models,
        join_models_count=join_models_count,
    )


@bp.route('/builder')
def builder():
    inspector = inspect(db.engine)
    internal_tables = set(db.metadata.tables.keys()) | {'alembic_version'}
    tables = [t for t in inspector.get_table_names() if t not in internal_tables]
    join_models = JoinModel.query.filter_by(is_archived=False).all()
    table_columns = {}
    for t in tables:
        table_columns[t] = [c['name'] for c in inspector.get_columns(t)]
    return render_template('reports/builder.html', tables=tables, join_models=join_models, table_columns=table_columns)
