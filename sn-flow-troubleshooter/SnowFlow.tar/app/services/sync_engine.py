import logging
from datetime import datetime
from app.extensions import db
from app.models.sync import SyncJobLog
from app.services.servicenow_client import ServiceNowClient

logger = logging.getLogger(__name__)

class SyncEngine:
    def __init__(self, config):
        self.config = config
        self.connection = config.connection
        self.client = ServiceNowClient(
            instance_url=self.connection.instance_url,
            username=self.connection.username,
            password=self.connection.password,
            api_version=self.connection.api_version
        )
        
    def start_sync(self):
        # Create a Job Log
        job_log = SyncJobLog(
            config_id=self.config.id,
            status='RUNNING',
            start_time=datetime.utcnow()
        )
        db.session.add(job_log)
        db.session.commit()
        
        try:
            # 1. Fetch metadata (dictionary)
            logger.info(f"Fetching metadata for {self.config.table_name}")
            dictionary = self.client.fetch_dictionary(self.config.table_name)
            
            # 2. Map dictionary to local schema (Dynamic Table Creation)
            # In Phase 2, we can just save it into a generic JSON/NoSQL column 
            # or dynamically build a SQLAlchemy Table. For simplicity and robustness
            # in sqlite/postgres, we will implement dynamic tables soon.
            # Right now we just fetch records to test the connection and log it.
            
            # 3. Fetch Data
            query = self.config.encoded_query
            if self.config.incremental_sync and self.config.last_sync_time:
                last_sync = self.config.last_sync_time.strftime("%Y-%m-%d %H:%M:%S")
                sys_query = f"sys_updated_on>={last_sync}"
                if query:
                    query = f"{query}^{sys_query}"
                else:
                    query = sys_query
                    
            logger.info(f"Fetching records for {self.config.table_name} with query: {query}")
            
            records = self.client.fetch_records(
                table_name=self.config.table_name,
                sysparm_query=query,
                sysparm_limit=self.config.batch_size
            )
            
            if records:
                from sqlalchemy import MetaData, Table, Column, Text, String
                from sqlalchemy.dialects.sqlite import insert as sqlite_insert
                
                # Use the first record to infer columns
                first_record = records[0]
                engine = db.engine
                metadata = MetaData()
                from app.models.sync import SyncTableConfig
                configs = SyncTableConfig.query.filter_by(table_name=self.config.table_name).order_by(SyncTableConfig.id).all()
                version_idx = 0
                for i, c in enumerate(configs):
                    if c.id == self.config.id:
                        version_idx = i
                        break
                local_table_name = self.config.table_name
                if version_idx > 0:
                    local_table_name = f"{self.config.table_name}_v{version_idx}"
                # Define table dynamically
                columns = [Column('sys_id', String(32), primary_key=True)]
                for key in first_record.keys():
                    if key != 'sys_id':
                        columns.append(Column(key, Text))
                        
                dynamic_table = Table(local_table_name, metadata, *columns)
                
                # Create table if it doesn't exist
                metadata.create_all(engine)
                
                # Insert or Update records in a transaction
                with engine.begin() as conn:
                    for record in records:
                        row_data = {}
                        for k, v in record.items():
                            if isinstance(v, dict):
                                # ServiceNow returns dict when sysparm_display_value=all
                                row_data[k] = str(v.get('value') or v.get('display_value') or '')
                            else:
                                row_data[k] = str(v) if v is not None else ''
                        
                        if 'sys_id' not in row_data:
                            continue
                            
                        stmt = sqlite_insert(dynamic_table).values(row_data)
                        update_dict = {c.name: c for c in stmt.excluded if c.name != 'sys_id'}
                        
                        if update_dict:
                            stmt = stmt.on_conflict_do_update(
                                index_elements=['sys_id'],
                                set_=update_dict
                            )
                        else:
                            stmt = stmt.on_conflict_do_nothing(index_elements=['sys_id'])
                        
                        conn.execute(stmt)
            job_log.status = 'SUCCESS'
            job_log.records_processed = len(records)
            job_log.end_time = datetime.utcnow()
            
            self.config.last_sync_time = datetime.utcnow()
            
            db.session.commit()
            return True, "Sync completed successfully"
            
        except Exception as e:
            job_log.status = 'FAILED'
            job_log.error_message = str(e)
            job_log.end_time = datetime.utcnow()
            db.session.commit()
            logger.error(f"Sync failed for {self.config.table_name}: {str(e)}")
            return False, str(e)
