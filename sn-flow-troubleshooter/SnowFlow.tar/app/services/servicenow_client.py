import requests
from requests.auth import HTTPBasicAuth
from urllib.parse import urljoin
import logging

logger = logging.getLogger(__name__)

class ServiceNowClient:
    def __init__(self, instance_url, username, password, api_version='v2'):
        # Ensure url does not have trailing slash
        self.instance_url = instance_url.rstrip('/')
        self.username = username
        self.password = password
        self.api_version = api_version
        self.base_api_url = f"{self.instance_url}/api/now/table/"
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(self.username, self.password)
        self.session.headers.update({
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })
    
    def fetch_records(self, table_name, sysparm_query=None, sysparm_limit=1000, sysparm_offset=0):
        url = urljoin(self.base_api_url, table_name)
        
        params = {
            'sysparm_limit': sysparm_limit,
            'sysparm_offset': sysparm_offset,
            'sysparm_display_value': 'all', # To get both display value and link
            'sysparm_exclude_reference_link': 'false'
        }
        
        if sysparm_query:
            params['sysparm_query'] = sysparm_query
            
        try:
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            data = response.json()
            return data.get('result', [])
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching from ServiceNow ({table_name}): {str(e)}")
            raise e
            
    def fetch_dictionary(self, table_name):
        """Fetch dictionary metadata to dynamically build tables"""
        # query sys_dictionary for the columns of a table
        query = f"name={table_name}"
        return self.fetch_records('sys_dictionary', sysparm_query=query, sysparm_limit=10000)
