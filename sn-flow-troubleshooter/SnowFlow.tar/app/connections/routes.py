from flask import render_template, request, redirect, url_for, flash
from app.connections import bp
from app.models.connection import ServiceNowConnection
from app.extensions import db

@bp.route('/')
def index():
    connections = ServiceNowConnection.query.all()
    return render_template('connections/index.html', connections=connections)

@bp.route('/create', methods=['POST'])
def create():
    name = request.form.get('name')
    instance_url = request.form.get('instance_url')
    username = request.form.get('username')
    password = request.form.get('password')
    
    # Simple validation
    if not all([name, instance_url, username, password]):
        flash('All fields are required', 'danger')
        return redirect(url_for('connections.index'))
        
    conn = ServiceNowConnection(
        name=name,
        instance_url=instance_url,
        username=username,
        password=password
    )
    db.session.add(conn)
    db.session.commit()
    
    flash('Connection created successfully!', 'success')
    return redirect(url_for('connections.index'))
    
@bp.route('/<int:id>/delete', methods=['POST'])
def delete(id):
    conn = ServiceNowConnection.query.get_or_404(id)
    db.session.delete(conn)
    db.session.commit()
    flash('Connection deleted successfully!', 'success')
    return redirect(url_for('connections.index'))
