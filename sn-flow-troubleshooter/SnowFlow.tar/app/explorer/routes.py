from flask import render_template, request, redirect, url_for, flash
from app.explorer import bp
from app.extensions import db
from app.models.relationships import JoinModel
from sqlalchemy import inspect, text


@bp.route('/')
def index():
    from app.models.explorer import SavedSqlQuery
    inspector = inspect(db.engine)
    tables = []
    with db.engine.connect() as conn:
        for t in inspector.get_table_names():
            internal_tables = set(db.metadata.tables.keys()) | {'alembic_version'}
            if t in internal_tables:
                continue
            cols = [c['name'] for c in inspector.get_columns(t)]
            count = conn.execute(text(f'SELECT COUNT(*) FROM "{t}"')).scalar()
            tables.append({'name': t, 'display': t, 'columns': cols, 'count': count})
            
    join_models = JoinModel.query.filter_by(is_archived=False).all()
    saved_queries = SavedSqlQuery.query.order_by(SavedSqlQuery.name).all()
    return render_template('explorer/index.html', tables=tables, join_models=join_models, saved_queries=saved_queries)


@bp.route('/<table>')
def view_table(table):
    inspector = inspect(db.engine)
    if table not in inspector.get_table_names():
        flash(f"Table '{table}' not found locally.", 'danger')
        return redirect(url_for('explorer.index'))
    columns = [{'name': c['name'], 'type': str(c['type'])} for c in inspector.get_columns(table)]
    return render_template('explorer/table.html', table_name=table, columns=columns, is_model=False)


@bp.route('/model/<int:model_id>')
def view_model(model_id):
    import json
    model = JoinModel.query.get_or_404(model_id)
        
    nodes = list(model.nodes)
    if not nodes:
        flash(f"Model '{model.name}' has no tables yet. Open the canvas and add tables.", 'warning')
        return redirect(url_for('explorer.index'))
        
    rels = [r for r in model.relationships if r.is_enabled]
    if not rels:
        flash(f"Model '{model.name}' has no relationships defined. Open the canvas and connect tables.", 'warning')
        return redirect(url_for('explorer.index'))

    base_table = nodes[0].table_name
    from_clause = f'FROM "{base_table}"'
    join_clauses = []

    seen = {base_table}
    for rel in rels:
        src = rel.source_table
        tgt = rel.target_table
        if tgt not in seen:
            condition = rel.sql_expression or f'"{src}"."{rel.source_field}" = "{tgt}"."{rel.target_field}"'
            join_clauses.append(f'{rel.join_type} "{tgt}" ON {condition}')
            seen.add(tgt)

    # Build SELECT using visible fields only
    inspector = inspect(db.engine)
    select_parts = []
    for node in nodes:
        tname = node.table_name
        if tname in inspector.get_table_names():
            all_cols = [c['name'] for c in inspector.get_columns(tname)]
            try:
                hidden = json.loads(node.hidden_fields) if node.hidden_fields else []
            except Exception:
                hidden = []
            visible = [c for c in all_cols if c not in hidden]
            for col in visible:
                select_parts.append(f'"{tname}"."{col}" AS "{tname}_{col}"')

    if not select_parts:
        select_parts = ['*']

    select_clause = 'SELECT ' + ', '.join(select_parts)
    from_part = from_clause
    if join_clauses:
        from_part += ' ' + ' '.join(join_clauses)
    full_sql = f'{select_clause} {from_part}'

    columns = []
    error_msg = None
    try:
        with db.engine.connect() as conn:
            result = conn.execute(text(full_sql + ' LIMIT 0'))
            columns = [{'name': k, 'type': 'UNKNOWN'} for k in result.keys()]
    except Exception as e:
        error_msg = str(e)
        # Fall back to all columns from all tables if SQL fails
        for node in nodes:
            tname = node.table_name
            if tname in inspector.get_table_names():
                all_cols = [c['name'] for c in inspector.get_columns(tname)]
                for col in all_cols:
                    columns.append({'name': f'{tname}_{col}', 'type': 'UNKNOWN'})

    if error_msg:
        flash(f"SQL Warning: {error_msg}. Showing all columns as fallback.", 'warning')

    return render_template('explorer/table.html',
        table_name=model.name,
        model_id=model.id,
        columns=columns,
        is_model=True,
        model=model
    )


@bp.route('/sql')
def view_sql():
    # Pass a blank default query view
    return render_template('explorer/custom_sql.html')


@bp.route('/sql/<int:query_id>')
def view_saved_sql(query_id):
    from app.models.explorer import SavedSqlQuery
    query = SavedSqlQuery.query.get_or_404(query_id)
    return render_template('explorer/custom_sql.html', saved_query=query)

