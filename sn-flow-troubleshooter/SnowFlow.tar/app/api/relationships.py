import json
from datetime import datetime
from flask import request, jsonify
from app.api import bp
from app.extensions import db
from app.models.relationships import JoinModel, CanvasNode, TableRelationship
from sqlalchemy import inspect


# ─────────────────────────────────────────────────────────────────────────────
# JOIN MODELS
# ─────────────────────────────────────────────────────────────────────────────

@bp.route('/join-models', methods=['GET'])
def list_join_models():
    archived = request.args.get('archived', 'false').lower() == 'true'
    q = request.args.get('q', '').strip()
    models = JoinModel.query.filter_by(is_archived=archived)
    if q:
        models = models.filter(JoinModel.name.ilike(f'%{q}%'))
    models = models.order_by(JoinModel.updated_at.desc()).all()
    return jsonify([m.to_dict() for m in models])


@bp.route('/join-models', methods=['POST'])
def create_join_model():
    data = request.get_json() or {}
    model = JoinModel(
        name=data.get('name', 'Untitled Model'),
        description=data.get('description', ''),
        tags=','.join(data.get('tags', [])),
        owner=data.get('owner', 'admin'),
    )
    db.session.add(model)
    db.session.commit()
    return jsonify(model.to_dict()), 201


@bp.route('/join-models/<int:model_id>', methods=['GET'])
def get_join_model(model_id):
    model = JoinModel.query.get_or_404(model_id)
    model.last_opened = datetime.utcnow()
    db.session.commit()
    return jsonify(model.to_dict(include_children=True))


@bp.route('/join-models/<int:model_id>', methods=['PUT'])
def update_join_model(model_id):
    model = JoinModel.query.get_or_404(model_id)
    data = request.get_json() or {}
    model.name = data.get('name', model.name)
    model.description = data.get('description', model.description)
    model.tags = ','.join(data.get('tags', [])) if 'tags' in data else model.tags
    model.is_favourite = data.get('is_favourite', model.is_favourite)
    model.is_archived = data.get('is_archived', model.is_archived)
    model.version = model.version + 1
    db.session.commit()
    return jsonify(model.to_dict())


@bp.route('/join-models/<int:model_id>', methods=['DELETE'])
def delete_join_model(model_id):
    model = JoinModel.query.get_or_404(model_id)
    db.session.delete(model)
    db.session.commit()
    return jsonify({'success': True})


@bp.route('/join-models/<int:model_id>/duplicate', methods=['POST'])
def duplicate_join_model(model_id):
    original = JoinModel.query.get_or_404(model_id)
    new_model = JoinModel(
        name=f"{original.name} (Copy)",
        description=original.description,
        tags=original.tags,
        owner=original.owner,
        canvas_meta=original.canvas_meta,
    )
    db.session.add(new_model)
    db.session.flush()

    for node in original.nodes:
        new_node = CanvasNode(
            model_id=new_model.id,
            table_name=node.table_name,
            display_name=node.display_name,
            x=node.x + 30, y=node.y + 30,
            width=node.width, height=node.height,
            color=node.color,
            is_collapsed=node.is_collapsed,
            notes=node.notes,
            pinned_fields=node.pinned_fields,
        )
        db.session.add(new_node)

    for rel in original.relationships:
        new_rel = TableRelationship(
            model_id=new_model.id,
            source_table=rel.source_table, source_field=rel.source_field,
            target_table=rel.target_table, target_field=rel.target_field,
            join_type=rel.join_type, alias=rel.alias,
            description=rel.description, sql_expression=rel.sql_expression,
            additional_conditions=rel.additional_conditions,
            is_enabled=rel.is_enabled, color=rel.color, line_style=rel.line_style,
        )
        db.session.add(new_rel)

    db.session.commit()
    return jsonify(new_model.to_dict()), 201


# ─────────────────────────────────────────────────────────────────────────────
# CANVAS SAVE (full state: nodes + relationships)
# ─────────────────────────────────────────────────────────────────────────────

@bp.route('/join-models/<int:model_id>/save-canvas', methods=['POST'])
def save_canvas(model_id):
    model = JoinModel.query.get_or_404(model_id)
    data = request.get_json() or {}

    # Save canvas meta (zoom, pan)
    model.canvas_meta = json.dumps(data.get('canvas_meta', {}))
    model.version = model.version + 1

    # Replace all nodes
    CanvasNode.query.filter_by(model_id=model_id).delete()
    for n in data.get('nodes', []):
        node = CanvasNode(
            model_id=model_id,
            table_name=n['table_name'],
            display_name=n.get('display_name'),
            x=n.get('x', 100), y=n.get('y', 100),
            width=n.get('width', 220), height=n.get('height', 300),
            color=n.get('color', '#6366f1'),
            is_collapsed=n.get('is_collapsed', False),
            is_pinned=n.get('is_pinned', False),
            is_locked=n.get('is_locked', False),
            notes=n.get('notes'),
            pinned_fields=json.dumps(n.get('pinned_fields', [])),
            hidden_fields=json.dumps(n.get('hidden_fields', [])),
        )
        db.session.add(node)

    # Replace all relationships
    TableRelationship.query.filter_by(model_id=model_id).delete()
    for r in data.get('relationships', []):
        rel = TableRelationship(
            model_id=model_id,
            source_table=r['source_table'], source_field=r['source_field'],
            target_table=r['target_table'], target_field=r['target_field'],
            join_type=r.get('join_type', 'INNER JOIN'),
            alias=r.get('alias'), description=r.get('description'),
            sql_expression=r.get('sql_expression'),
            additional_conditions=r.get('additional_conditions'),
            is_enabled=r.get('is_enabled', True),
            color=r.get('color', '#6366f1'),
            line_style=r.get('line_style', 'curved'),
        )
        db.session.add(rel)

    db.session.commit()
    return jsonify({'success': True, 'version': model.version})


# ─────────────────────────────────────────────────────────────────────────────
# AUTO-SUGGEST JOINS
# ─────────────────────────────────────────────────────────────────────────────

@bp.route('/join-models/<int:model_id>/suggest-joins', methods=['GET'])
def suggest_joins(model_id):
    model = JoinModel.query.get_or_404(model_id)
    inspector = inspect(db.engine)

    # Get all node table names in this model
    node_tables = [n.table_name for n in model.nodes]
    suggestions = []

    for source_table in node_tables:
        if source_table not in inspector.get_table_names():
            continue
        source_cols = {c['name'] for c in inspector.get_columns(source_table)}

        for target_table in node_tables:
            if target_table == source_table:
                continue
            if target_table not in inspector.get_table_names():
                continue
            target_cols = {c['name'] for c in inspector.get_columns(target_table)}

            # Check for sys_id match (ServiceNow pattern: field_name == target_table without _id)
            target_base = target_table
            for col in source_cols:
                # Pattern 1: source has a field that matches target table name (e.g. caller_id, assignment_group)
                if col == 'sys_id' and 'sys_id' in target_cols:
                    pass  # skip trivial sys_id matches
                # Pattern 2: field name contains the target base table name
                elif target_base in col and 'sys_id' in target_cols:
                    suggestions.append({
                        'source_table': source_table,
                        'source_field': col,
                        'target_table': target_table,
                        'target_field': 'sys_id',
                        'join_type': 'LEFT JOIN',
                        'confidence': 'medium',
                        'reason': f"Field '{col}' likely references '{target_table}'",
                    })
                # Pattern 3: exact matching field names
                elif col in target_cols and col != 'sys_id':
                    suggestions.append({
                        'source_table': source_table,
                        'source_field': col,
                        'target_table': target_table,
                        'target_field': col,
                        'join_type': 'LEFT JOIN',
                        'confidence': 'low',
                        'reason': f"Matching field name '{col}' in both tables",
                    })

    return jsonify(suggestions[:20])  # cap at 20


# ─────────────────────────────────────────────────────────────────────────────
# GENERATE SQL
# ─────────────────────────────────────────────────────────────────────────────

@bp.route('/join-models/<int:model_id>/generate-sql', methods=['GET'])
def generate_sql(model_id):
    model = JoinModel.query.get_or_404(model_id)
    nodes = list(model.nodes)
    rels = [r for r in model.relationships if r.is_enabled]

    if not nodes:
        return jsonify({'sql': '-- No tables on canvas'})

    base_table = nodes[0].table_name
    base_alias = base_table
    from_clause = f'FROM "{base_table}" AS "{base_alias}"'
    join_clauses = []

    seen = {base_table}
    for rel in rels:
        src = rel.source_table
        tgt = rel.target_table
        if tgt not in seen:
            tgt_alias = tgt
            condition = rel.sql_expression or f'"{src}"."{rel.source_field}" = "{tgt_alias}"."{rel.target_field}"'
            join_clauses.append(f'{rel.join_type} "{tgt}" AS "{tgt_alias}"\n  ON {condition}')
            seen.add(tgt)

    inspector = inspect(db.engine)
    select_fields = []
    for node in nodes:
        tname = node.table_name
        if tname in inspector.get_table_names():
            all_cols = [c['name'] for c in inspector.get_columns(tname)]
            try:
                import json
                hidden = json.loads(node.hidden_fields) if node.hidden_fields else []
            except:
                hidden = []
            visible_cols = [c for c in all_cols if c not in hidden]
            for col in visible_cols:
                select_fields.append(f'  "{tname}"."{col}" AS "{tname}_{col}"')

    if not select_fields:
        select_fields = ["  *"]

    sql = from_clause
    if join_clauses:
        sql += '\n' + '\n'.join(join_clauses)
    full_sql = 'SELECT\n' + ',\n'.join(select_fields) + '\n' + sql
    return jsonify({'sql': full_sql})


# ─────────────────────────────────────────────────────────────────────────────
# TABLE METADATA (for canvas node field lists)
# ─────────────────────────────────────────────────────────────────────────────

@bp.route('/tables', methods=['GET'])
def list_tables():
    inspector = inspect(db.engine)
    tables = []
    internal_tables = set(db.metadata.tables.keys()) | {'alembic_version'}
    for t in inspector.get_table_names():
        if t not in internal_tables:
            cols = [c['name'] for c in inspector.get_columns(t)]
            tables.append({'name': t, 'columns': cols})
    return jsonify(tables)
