import json
import uuid
from flask import request, jsonify
from app.api import bp
from app.extensions import db
from app.models.explorer import SavedFilter, SavedView
from sqlalchemy import inspect, Table, MetaData, text
from sqlalchemy.dialects.sqlite import insert as sqlite_insert


def _get_dynamic_table(table_name):
    meta = MetaData()
    return Table(table_name, meta, autoload_with=db.engine)


def _get_sn_tables():
    inspector = inspect(db.engine)
    internal_tables = set(db.metadata.tables.keys()) | {'alembic_version'}
    return [t for t in inspector.get_table_names() if t not in internal_tables]


# ─────────────────────────────────────────────────────────────────────────────
# TABLE LIST
# ─────────────────────────────────────────────────────────────────────────────

@bp.route('/explorer/tables', methods=['GET'])
def explorer_list_tables():
    inspector = inspect(db.engine)
    tables = []
    with db.engine.connect() as conn:
        for t in inspector.get_table_names():
            internal_tables = set(db.metadata.tables.keys()) | {'alembic_version'}
            if t in internal_tables:
                continue
            cols = [{'name': c['name'], 'type': str(c['type'])} for c in inspector.get_columns(t)]
            count = conn.execute(text(f'SELECT COUNT(*) FROM "{t}"')).scalar()
            tables.append({'name': t, 'columns': cols, 'count': count})
    return jsonify(tables)


@bp.route('/explorer/tables/<table>/columns', methods=['GET'])
def get_table_columns(table):
    inspector = inspect(db.engine)
    if table not in inspector.get_table_names():
        return jsonify({'error': 'Table not found'}), 404
    cols = [{'name': c['name'], 'type': str(c['type'])} for c in inspector.get_columns(table)]
    return jsonify(cols)


# ─────────────────────────────────────────────────────────────────────────────
# RECORDS — server-side paginated with search & filter
# ─────────────────────────────────────────────────────────────────────────────

def _build_where_clause(cols, search, filters, sql_filter, params):
    where_parts = []
    
    if search:
        search_conditions = []
        for i, col in enumerate(cols):
            k = f'search_{i}'
            search_conditions.append(f'"{col}" LIKE :{k}')
            params[k] = f'%{search}%'
        if search_conditions:
            where_parts.append(f"({' OR '.join(search_conditions)})")

    for fi, f in enumerate(filters):
        field = f.get('field', '')
        op = f.get('op', 'contains')
        value = f.get('value', '')
        logic = f.get('logic', 'AND')
        if not field or field not in cols:
            continue
        k = f'filter_{fi}'
        if op == 'contains':
            where_parts.append(f'"{field}" LIKE :{k}')
            params[k] = f'%{value}%'
        elif op == 'equals':
            where_parts.append(f'"{field}" = :{k}')
            params[k] = value
        elif op == 'starts_with':
            where_parts.append(f'"{field}" LIKE :{k}')
            params[k] = f'{value}%'
        elif op == 'ends_with':
            where_parts.append(f'"{field}" LIKE :{k}')
            params[k] = f'%{value}'
        elif op == 'not_equals':
            where_parts.append(f'"{field}" != :{k}')
            params[k] = value
        elif op == 'is_empty':
            where_parts.append(f'("{field}" IS NULL OR "{field}" = \'\')')
        elif op == 'is_not_empty':
            where_parts.append(f'("{field}" IS NOT NULL AND "{field}" != \'\')')
            
    if sql_filter:
        # Wrap raw sql to ensure it acts as a single condition block
        where_parts.append(f"({sql_filter})")
            
    if where_parts:
        return 'WHERE ' + ' AND '.join(where_parts)
    return ''

@bp.route('/explorer/tables/<table>/records', methods=['GET'])
def get_records(table):
    inspector = inspect(db.engine)
    if table not in inspector.get_table_names():
        return jsonify({'error': 'Table not found'}), 404

    page = int(request.args.get('page', 1))
    page_size = min(int(request.args.get('page_size', 50)), 500)
    search = request.args.get('search', '').strip()
    sort_field = request.args.get('sort_field', 'sys_id')
    sort_dir = request.args.get('sort_dir', 'asc').upper()
    filters_raw = request.args.get('filters', '[]')
    sql_filter = request.args.get('sql_filter', '').strip()

    try:
        filters = json.loads(filters_raw)
    except Exception:
        filters = []

    cols = [c['name'] for c in inspector.get_columns(table)]
    offset = (page - 1) * page_size

    params = {}
    where_sql = _build_where_clause(cols, search, filters, sql_filter, params)

    sort_col = sort_field if sort_field in cols else cols[0]
    sort_sql = f'ORDER BY "{sort_col}" {sort_dir}'

    data_sql = text(f'SELECT * FROM "{table}" {where_sql} {sort_sql} LIMIT :limit OFFSET :offset')
    count_sql = text(f'SELECT COUNT(*) FROM "{table}" {where_sql}')
    params['limit'] = page_size
    params['offset'] = offset

    try:
        with db.engine.connect() as conn:
            total = conn.execute(count_sql, params).scalar()
            rows = conn.execute(data_sql, params).fetchall()
            records = [dict(r._mapping) for r in rows]
    except Exception as e:
        return jsonify({'error': str(e)}), 400

    return jsonify({
        'records': records,
        'total': total,
        'page': page,
        'page_size': page_size,
        'total_pages': (total + page_size - 1) // page_size,
        'columns': cols,
    })


@bp.route('/explorer/models/<int:model_id>/records', methods=['GET'])
def get_model_records(model_id):
    from app.models.relationships import JoinModel
    
    model = JoinModel.query.get_or_404(model_id)
    nodes = list(model.nodes)
    if not nodes:
        return jsonify({'error': 'No tables in model. Open the canvas and add tables.'}), 400
        
    rels = [r for r in model.relationships if r.is_enabled]
    if not rels:
        return jsonify({'error': 'No relationships defined. Open the canvas and connect tables with join lines.'}), 400

    base_table = nodes[0].table_name
    # Use plain quoted table name — no alias needed for simple joins
    from_clause = f'FROM "{base_table}"'
    join_clauses = []

    seen = {base_table}
    for rel in rels:
        src = rel.source_table
        tgt = rel.target_table
        if tgt not in seen:
            condition = rel.sql_expression or f'"{src}"."{rel.source_field}" = "{tgt}"."{rel.target_field}"'
            join_clauses.append(f'{rel.join_type} "{tgt}" ON {condition}')
            seen.add(tgt)

    inspector = inspect(db.engine)
    select_fields = []
    for node in nodes:
        tname = node.table_name
        if tname in inspector.get_table_names():
            all_cols = [c['name'] for c in inspector.get_columns(tname)]
            try:
                hidden = json.loads(node.hidden_fields) if node.hidden_fields else []
            except Exception:
                hidden = []
            visible_cols = [c for c in all_cols if c not in hidden]
            for col in visible_cols:
                select_fields.append(f'"{tname}"."{col}" AS "{tname}_{col}"')

    if not select_fields:
        # fallback: select all from all tables
        for node in nodes:
            tname = node.table_name
            if tname in inspector.get_table_names():
                for c in inspector.get_columns(tname):
                    select_fields.append(f'"{tname}"."{c["name"]}" AS "{tname}_{c["name"]}"')

    sql = from_clause
    if join_clauses:
        sql += ' ' + ' '.join(join_clauses)
    full_inner_sql = 'SELECT ' + ', '.join(select_fields) + ' ' + sql

    page = int(request.args.get('page', 1))
    page_size = min(int(request.args.get('page_size', 50)), 500)
    search = request.args.get('search', '').strip()
    sort_field = request.args.get('sort_field', '')
    sort_dir = request.args.get('sort_dir', 'asc').upper()
    filters_raw = request.args.get('filters', '[]')
    sql_filter = request.args.get('sql_filter', '').strip()

    try:
        filters = json.loads(filters_raw)
    except Exception:
        filters = []
        
    offset = (page - 1) * page_size

    try:
        with db.engine.connect() as conn:
            # Execute limit 0 to get column names for building where clause
            result = conn.execute(text(full_inner_sql + ' LIMIT 0'))
            cols = list(result.keys())
            
            params = {}
            where_sql = _build_where_clause(cols, search, filters, sql_filter, params)
            
            sort_sql = ''
            if sort_field and sort_field in cols:
                sort_sql = f'ORDER BY "{sort_field}" {sort_dir}'
                
            # Wrap as a subquery to safely apply limits and offsets
            data_sql = text(f'SELECT * FROM ({full_inner_sql}) AS joined_data {where_sql} {sort_sql} LIMIT :limit OFFSET :offset')
            count_sql = text(f'SELECT COUNT(*) FROM ({full_inner_sql}) AS joined_data {where_sql}')
            params['limit'] = page_size
            params['offset'] = offset
            
            total = conn.execute(count_sql, params).scalar()
            rows = conn.execute(data_sql, params).fetchall()
            records = [dict(r._mapping) for r in rows]
            
        return jsonify({
            'records': records,
            'total': total,
            'page': page,
            'page_size': page_size,
            'total_pages': (total + page_size - 1) // page_size,
            'columns': cols,
        })
    except Exception as e:
        return jsonify({'error': str(e), 'sql': full_inner_sql}), 400


@bp.route('/explorer/tables/<table>/records/<sys_id>', methods=['GET'])
def get_record(table, sys_id):
    inspector = inspect(db.engine)
    if table not in inspector.get_table_names():
        return jsonify({'error': 'Table not found'}), 404
    dyn = _get_dynamic_table(table)
    with db.engine.connect() as conn:
        row = conn.execute(dyn.select().where(dyn.c.sys_id == sys_id)).fetchone()
    if not row:
        return jsonify({'error': 'Record not found'}), 404
    return jsonify(dict(row._mapping))


@bp.route('/explorer/tables/<table>/records', methods=['POST'])
def create_record(table):
    inspector = inspect(db.engine)
    if table not in inspector.get_table_names():
        return jsonify({'error': 'Table not found'}), 404
    data = request.get_json() or {}
    if not data.get('sys_id'):
        data['sys_id'] = uuid.uuid4().hex
    dyn = _get_dynamic_table(table)
    with db.engine.begin() as conn:
        stmt = sqlite_insert(dyn).values(data)
        conn.execute(stmt.on_conflict_do_nothing(index_elements=['sys_id']))
    return jsonify({'success': True, 'sys_id': data['sys_id']}), 201


@bp.route('/explorer/tables/<table>/records/<sys_id>', methods=['PUT'])
def update_record(table, sys_id):
    inspector = inspect(db.engine)
    if table not in inspector.get_table_names():
        return jsonify({'error': 'Table not found'}), 404
    data = request.get_json() or {}
    data['sys_id'] = sys_id
    dyn = _get_dynamic_table(table)
    with db.engine.begin() as conn:
        stmt = sqlite_insert(dyn).values(data)
        update_dict = {c.name: c for c in stmt.excluded if c.name != 'sys_id'}
        if update_dict:
            stmt = stmt.on_conflict_do_update(index_elements=['sys_id'], set_=update_dict)
        conn.execute(stmt)
    return jsonify({'success': True})


@bp.route('/explorer/tables/<table>/records/<sys_id>', methods=['DELETE'])
def delete_record_api(table, sys_id):
    inspector = inspect(db.engine)
    if table not in inspector.get_table_names():
        return jsonify({'error': 'Table not found'}), 404
    dyn = _get_dynamic_table(table)
    with db.engine.begin() as conn:
        conn.execute(dyn.delete().where(dyn.c.sys_id == sys_id))
    return jsonify({'success': True})


# ─────────────────────────────────────────────────────────────────────────────
# BULK OPERATIONS
# ─────────────────────────────────────────────────────────────────────────────

@bp.route('/explorer/tables/<table>/records/bulk-delete', methods=['POST'])
def bulk_delete_records(table):
    data = request.get_json() or {}
    sys_ids = data.get('sys_ids', [])
    if not sys_ids:
        return jsonify({'error': 'No sys_ids provided'}), 400
    inspector = inspect(db.engine)
    if table not in inspector.get_table_names():
        return jsonify({'error': 'Table not found'}), 404
    dyn = _get_dynamic_table(table)
    with db.engine.begin() as conn:
        conn.execute(dyn.delete().where(dyn.c.sys_id.in_(sys_ids)))
    return jsonify({'success': True, 'deleted': len(sys_ids)})


@bp.route('/explorer/tables/<table>', methods=['DELETE'])
def delete_table_api(table):
    inspector = inspect(db.engine)
    if table not in inspector.get_table_names():
        return jsonify({'error': 'Table not found'}), 404
    
    # Drop the table
    with db.engine.begin() as conn:
        conn.execute(text(f'DROP TABLE "{table}"'))
        
    return jsonify({'success': True})


@bp.route('/explorer/tables', methods=['POST'])
def create_table_api():
    data = request.get_json() or {}
    table_name = data.get('name')
    if not table_name:
        return jsonify({'error': 'Table name is required'}), 400
    
    inspector = inspect(db.engine)
    if table_name in inspector.get_table_names():
        return jsonify({'error': 'Table already exists'}), 400
        
    with db.engine.begin() as conn:
        conn.execute(text(f'CREATE TABLE "{table_name}" (sys_id VARCHAR(32) PRIMARY KEY)'))
        
    return jsonify({'success': True, 'name': table_name}), 201


@bp.route('/explorer/tables/<table>', methods=['PUT'])
def rename_table_api(table):
    data = request.get_json() or {}
    new_name = data.get('name')
    if not new_name:
        return jsonify({'error': 'New table name is required'}), 400
        
    inspector = inspect(db.engine)
    if table not in inspector.get_table_names():
        return jsonify({'error': 'Table not found'}), 404
    if new_name in inspector.get_table_names():
        return jsonify({'error': 'A table with the new name already exists'}), 400
        
    with db.engine.begin() as conn:
        conn.execute(text(f'ALTER TABLE "{table}" RENAME TO "{new_name}"'))
        
    return jsonify({'success': True, 'name': new_name})


# ─────────────────────────────────────────────────────────────────────────────
# SAVED FILTERS
# ─────────────────────────────────────────────────────────────────────────────

@bp.route('/explorer/tables/<table>/saved-filters', methods=['GET'])
def list_saved_filters(table):
    filters = SavedFilter.query.filter_by(table_name=table).all()
    return jsonify([f.to_dict() for f in filters])


@bp.route('/explorer/tables/<table>/saved-filters', methods=['POST'])
def create_saved_filter(table):
    data = request.get_json() or {}
    sf = SavedFilter(
        table_name=table,
        name=data.get('name', 'Unnamed Filter'),
        filter_json=json.dumps(data.get('filter_json', [])),
        is_sql=data.get('is_sql', False),
        sql_query=data.get('sql_query', ''),
        is_favourite=data.get('is_favourite', False),
    )
    db.session.add(sf)
    db.session.commit()
    return jsonify({'success': True, 'id': sf.id})

@bp.route('/explorer/models/<int:model_id>/saved-filters', methods=['GET'])
def list_model_saved_filters(model_id):
    filters = SavedFilter.query.filter_by(table_name=f'model_{model_id}').all()
    return jsonify([f.to_dict() for f in filters])

@bp.route('/explorer/models/<int:model_id>/saved-filters', methods=['POST'])
def create_model_saved_filter(model_id):
    data = request.get_json() or {}
    sf = SavedFilter(
        table_name=f'model_{model_id}',
        name=data.get('name', 'Unnamed Filter'),
        filter_json=json.dumps(data.get('filter_json', [])),
        is_sql=data.get('is_sql', False),
        sql_query=data.get('sql_query', ''),
        is_favourite=data.get('is_favourite', False),
    )
    db.session.add(sf)
    db.session.commit()
    return jsonify({'success': True, 'id': sf.id}), 201


@bp.route('/explorer/saved-filters/<int:filter_id>', methods=['DELETE'])
def delete_saved_filter(filter_id):
    sf = SavedFilter.query.get_or_404(filter_id)
    db.session.delete(sf)
    db.session.commit()
    return jsonify({'success': True})


# ─────────────────────────────────────────────────────────────────────────────
# CUSTOM SQL QUERIES
# ─────────────────────────────────────────────────────────────────────────────

@bp.route('/explorer/queries', methods=['GET'])
def list_queries():
    from app.models.explorer import SavedSqlQuery
    queries = SavedSqlQuery.query.order_by(SavedSqlQuery.name).all()
    return jsonify([q.to_dict() for q in queries])


@bp.route('/explorer/queries', methods=['POST'])
def create_query():
    from app.models.explorer import SavedSqlQuery
    data = request.get_json() or {}
    
    if not data.get('name') or not data.get('query_text'):
        return jsonify({'error': 'Name and query text are required'}), 400
        
    query = SavedSqlQuery(
        name=data['name'],
        description=data.get('description', ''),
        query_text=data['query_text'],
        is_favourite=data.get('is_favourite', False)
    )
    db.session.add(query)
    db.session.commit()
    return jsonify({'success': True, 'id': query.id}), 201


@bp.route('/explorer/queries/<int:query_id>', methods=['PUT'])
def update_query(query_id):
    from app.models.explorer import SavedSqlQuery
    query = SavedSqlQuery.query.get_or_404(query_id)
    data = request.get_json() or {}
    
    if 'name' in data:
        query.name = data['name']
    if 'description' in data:
        query.description = data['description']
    if 'query_text' in data:
        query.query_text = data['query_text']
    if 'is_favourite' in data:
        query.is_favourite = data['is_favourite']
        
    db.session.commit()
    return jsonify({'success': True})


@bp.route('/explorer/queries/<int:query_id>', methods=['DELETE'])
def delete_query(query_id):
    from app.models.explorer import SavedSqlQuery
    query = SavedSqlQuery.query.get_or_404(query_id)
    db.session.delete(query)
    db.session.commit()
    return jsonify({'success': True})


@bp.route('/explorer/queries/execute', methods=['POST'])
def execute_query():
    data = request.get_json() or {}
    query_text = data.get('query_text', '').strip()
    
    if not query_text:
        return jsonify({'error': 'No query provided'}), 400
        
    # Basic safety checks
    lower_query = query_text.lower()
    restricted = ['insert ', 'update ', 'delete ', 'drop ', 'alter ', 'truncate ', 'replace ', 'grant ', 'revoke ']
    if any(keyword in lower_query for keyword in restricted):
        return jsonify({'error': 'Only SELECT queries are allowed for security reasons.'}), 400
        
    page = int(request.args.get('page', 1))
    page_size = min(int(request.args.get('page_size', 100)), 500)
    offset = (page - 1) * page_size
    
    try:
        with db.engine.connect() as conn:
            # Check columns first (limit 0 to be safe/fast)
            try:
                result = conn.execute(text(f"{query_text} LIMIT 0"))
                cols = list(result.keys())
            except Exception as e:
                return jsonify({'error': f"Syntax Error: {str(e)}"}), 400

            # Execute actual query with pagination
            # Wrap as a subquery to safely apply limits and offsets
            data_sql = text(f'SELECT * FROM ({query_text}) AS custom_query LIMIT :limit OFFSET :offset')
            count_sql = text(f'SELECT COUNT(*) FROM ({query_text}) AS custom_query')
            
            params = {'limit': page_size, 'offset': offset}
            
            total = conn.execute(count_sql).scalar()
            rows = conn.execute(data_sql, params).fetchall()
            records = [dict(r._mapping) for r in rows]
            
        return jsonify({
            'records': records,
            'total': total,
            'page': page,
            'page_size': page_size,
            'total_pages': (total + page_size - 1) // page_size,
            'columns': cols,
        })
    except Exception as e:
        return jsonify({'error': f"Execution Error: {str(e)}"}), 400

