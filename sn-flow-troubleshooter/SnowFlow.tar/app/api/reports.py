from flask import request, jsonify
from app.api import bp
from app.extensions import db
from app.models.sync import SyncTableConfig, SyncJobLog
from sqlalchemy import inspect, text


@bp.route('/reports/table-stats', methods=['GET'])
def table_stats():
    inspector = inspect(db.engine)
    tables = [t for t in inspector.get_table_names() if t.startswith('sn_')]
    stats = []
    with db.engine.connect() as conn:
        for t in tables:
            count = conn.execute(text(f'SELECT COUNT(*) FROM "{t}"')).scalar()
            stats.append({'table': t, 'count': count})
    return jsonify(stats)


@bp.route('/reports/sync-history', methods=['GET'])
def sync_history():
    logs = SyncJobLog.query.order_by(SyncJobLog.start_time.desc()).limit(100).all()
    result = []
    for log in logs:
        config = SyncTableConfig.query.get(log.config_id)
        result.append({
            'id': log.id,
            'table': config.table_name if config else 'Unknown',
            'label': config.label if config else 'Unknown',
            'status': log.status,
            'records_processed': log.records_processed,
            'error_message': log.error_message,
            'start_time': log.start_time.isoformat() if log.start_time else None,
            'end_time': log.end_time.isoformat() if log.end_time else None,
            'duration_seconds': (
                (log.end_time - log.start_time).total_seconds()
                if log.end_time and log.start_time else None
            ),
        })
    return jsonify(result)


@bp.route('/reports/table/<table>/aggregate', methods=['GET'])
def table_aggregate(table):
    inspector = inspect(db.engine)
    if table not in inspector.get_table_names():
        return jsonify({'error': 'Table not found'}), 404

    group_field = request.args.get('group_by')
    cols = [c['name'] for c in inspector.get_columns(table)]

    if not group_field or group_field not in cols:
        return jsonify({'error': 'Invalid group_by field'}), 400

    with db.engine.connect() as conn:
        result = conn.execute(
            text(f'SELECT "{group_field}", COUNT(*) as count FROM "{table}" GROUP BY "{group_field}" ORDER BY count DESC LIMIT 50')
        ).fetchall()
        rows = [{'value': r[0] or '(empty)', 'count': r[1]} for r in result]

    return jsonify({'field': group_field, 'table': table, 'data': rows})
