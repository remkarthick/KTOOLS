from flask import render_template, request, redirect, url_for, flash
from app.sync import bp
from app.models.sync import SyncTableConfig, SyncJobLog
from app.models.connection import ServiceNowConnection
from app.extensions import db

@bp.route('/')
def index():
    configs = SyncTableConfig.query.all()
    connections = ServiceNowConnection.query.filter_by(is_active=True).all()
    return render_template('sync/index.html', configs=configs, connections=connections)

@bp.route('/create', methods=['POST'])
def create():
    connection_id = request.form.get('connection_id')
    table_name = request.form.get('table_name')
    label = request.form.get('label')
    batch_size = request.form.get('batch_size') or 1000
    encoded_query = request.form.get('encoded_query')
    
    if not all([connection_id, table_name]):
        flash('Connection and Table Name are required', 'danger')
        return redirect(url_for('sync.index'))
        
    config = SyncTableConfig(
        connection_id=connection_id,
        table_name=table_name,
        label=label or table_name,
        batch_size=int(batch_size),
        encoded_query=encoded_query
    )
    db.session.add(config)
    db.session.commit()
    
    flash('Sync configuration created successfully!', 'success')
    return redirect(url_for('sync.index'))

@bp.route('/<int:id>/delete', methods=['POST'])
def delete(id):
    config = SyncTableConfig.query.get_or_404(id)
    db.session.delete(config)
    db.session.commit()
    flash('Sync configuration deleted successfully!', 'success')
    return redirect(url_for('sync.index'))

@bp.route('/<int:id>/sync', methods=['POST'])
def trigger_sync(id):
    from app.services.sync_engine import SyncEngine
    config = SyncTableConfig.query.get_or_404(id)
    
    engine = SyncEngine(config)
    success, message = engine.start_sync()
    
    if success:
        flash(message, 'success')
    else:
        flash(f"Sync failed: {message}", 'danger')
        
    return redirect(url_for('sync.index'))
