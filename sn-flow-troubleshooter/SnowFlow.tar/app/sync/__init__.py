from flask import Blueprint

bp = Blueprint('sync', __name__)

from app.sync import routes
