from app.models.base import BaseModel
from app.extensions import db

class SyncTableConfig(BaseModel):
    __tablename__ = 'sync_table_configs'
    
    connection_id = db.Column(db.Integer, db.ForeignKey('servicenow_connections.id'), nullable=False)
    table_name = db.Column(db.String(100), nullable=False)
    label = db.Column(db.String(100))
    is_active = db.Column(db.Boolean, default=True)
    incremental_sync = db.Column(db.Boolean, default=True)
    batch_size = db.Column(db.Integer, default=1000)
    sync_order = db.Column(db.Integer, default=0)
    encoded_query = db.Column(db.String(500))
    last_sync_time = db.Column(db.DateTime)
    
    connection = db.relationship('ServiceNowConnection', backref=db.backref('sync_configs', lazy=True, cascade='all, delete'))
    
    def __repr__(self):
        return f'<SyncTableConfig {self.table_name}>'

class SyncJobLog(BaseModel):
    __tablename__ = 'sync_job_logs'
    
    config_id = db.Column(db.Integer, db.ForeignKey('sync_table_configs.id'), nullable=False)
    status = db.Column(db.String(50), nullable=False) # e.g., RUNNING, SUCCESS, FAILED
    records_processed = db.Column(db.Integer, default=0)
    error_message = db.Column(db.Text)
    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime)
    
    config = db.relationship('SyncTableConfig', backref=db.backref('logs', lazy=True, cascade='all, delete'))
