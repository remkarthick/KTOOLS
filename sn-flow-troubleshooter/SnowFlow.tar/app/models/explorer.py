import json
from app.models.base import BaseModel
from app.extensions import db


class SavedFilter(BaseModel):
    """A named filter configuration for a Data Explorer table."""
    __tablename__ = 'saved_filters'

    table_name = db.Column(db.String(100), nullable=False)
    name = db.Column(db.String(150), nullable=False)
    filter_json = db.Column(db.Text, default='[]')  # list of filter conditions
    is_sql = db.Column(db.Boolean, default=False)
    sql_query = db.Column(db.Text)
    is_favourite = db.Column(db.Boolean, default=False)
    owner = db.Column(db.String(100), default='admin')

    def to_dict(self):
        return {
            'id': self.id,
            'table_name': self.table_name,
            'name': self.name,
            'filter_json': json.loads(self.filter_json or '[]'),
            'is_sql': self.is_sql,
            'sql_query': self.sql_query,
            'is_favourite': self.is_favourite,
            'owner': self.owner,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }

    def __repr__(self):
        return f'<SavedFilter {self.table_name}:{self.name}>'


class SavedView(BaseModel):
    """A named column/sort layout for a Data Explorer table."""
    __tablename__ = 'saved_views'

    table_name = db.Column(db.String(100), nullable=False)
    name = db.Column(db.String(150), nullable=False)
    columns_json = db.Column(db.Text, default='[]')   # ordered list of visible column names
    sort_json = db.Column(db.Text, default='[]')       # list of {field, direction}
    is_default = db.Column(db.Boolean, default=False)
    owner = db.Column(db.String(100), default='admin')

    def to_dict(self):
        return {
            'id': self.id,
            'table_name': self.table_name,
            'name': self.name,
            'columns_json': json.loads(self.columns_json or '[]'),
            'sort_json': json.loads(self.sort_json or '[]'),
            'is_default': self.is_default,
            'owner': self.owner,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }

    def __repr__(self):
        return f'<SavedView {self.table_name}:{self.name}>'


class SavedSqlQuery(BaseModel):
    """A named custom SQL query."""
    __tablename__ = 'saved_sql_queries'

    name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    query_text = db.Column(db.Text, nullable=False)
    owner = db.Column(db.String(100), default='admin')
    is_favourite = db.Column(db.Boolean, default=False)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'query_text': self.query_text,
            'owner': self.owner,
            'is_favourite': self.is_favourite,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
        }

    def __repr__(self):
        return f'<SavedSqlQuery {self.name}>'
