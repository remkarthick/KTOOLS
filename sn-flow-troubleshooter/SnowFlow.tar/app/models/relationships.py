import json
from datetime import datetime
from app.models.base import BaseModel
from app.extensions import db


class JoinModel(BaseModel):
    """A named canvas containing table nodes and their relationships."""
    __tablename__ = 'join_models'

    name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text)
    tags = db.Column(db.String(500))          # comma-separated
    is_favourite = db.Column(db.Boolean, default=False)
    is_archived = db.Column(db.Boolean, default=False)
    version = db.Column(db.Integer, default=1)
    owner = db.Column(db.String(100), default='admin')
    canvas_meta = db.Column(db.Text, default='{}')  # zoom, pan offset, etc.
    last_opened = db.Column(db.DateTime)

    nodes = db.relationship('CanvasNode', backref='model', cascade='all, delete-orphan', lazy='dynamic')
    relationships = db.relationship('TableRelationship', backref='model', cascade='all, delete-orphan', lazy='dynamic')

    def to_dict(self, include_children=False):
        d = {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'tags': self.tags.split(',') if self.tags else [],
            'is_favourite': self.is_favourite,
            'is_archived': self.is_archived,
            'version': self.version,
            'owner': self.owner,
            'canvas_meta': json.loads(self.canvas_meta or '{}'),
            'last_opened': self.last_opened.isoformat() if self.last_opened else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
        }
        if include_children:
            d['nodes'] = [n.to_dict() for n in self.nodes]
            d['relationships'] = [r.to_dict() for r in self.relationships]
        return d

    def __repr__(self):
        return f'<JoinModel {self.name}>'


class CanvasNode(BaseModel):
    """Position and visual state of a table node on a canvas."""
    __tablename__ = 'canvas_nodes'

    model_id = db.Column(db.Integer, db.ForeignKey('join_models.id'), nullable=False)
    table_name = db.Column(db.String(100), nullable=False)
    display_name = db.Column(db.String(150))
    x = db.Column(db.Float, default=100)
    y = db.Column(db.Float, default=100)
    width = db.Column(db.Float, default=220)
    height = db.Column(db.Float, default=300)
    color = db.Column(db.String(20), default='#6366f1')
    is_collapsed = db.Column(db.Boolean, default=False)
    is_pinned = db.Column(db.Boolean, default=False)
    is_locked = db.Column(db.Boolean, default=False)
    notes = db.Column(db.Text)
    pinned_fields = db.Column(db.Text, default='[]')  # JSON list of field names to always show
    hidden_fields = db.Column(db.Text, default='[]')  # JSON list of field names to hide

    def to_dict(self):
        return {
            'id': self.id,
            'model_id': self.model_id,
            'table_name': self.table_name,
            'display_name': self.display_name or self.table_name,
            'x': self.x,
            'y': self.y,
            'width': self.width,
            'height': self.height,
            'color': self.color,
            'is_collapsed': self.is_collapsed,
            'is_pinned': self.is_pinned,
            'is_locked': self.is_locked,
            'notes': self.notes,
            'pinned_fields': json.loads(self.pinned_fields or '[]'),
            'hidden_fields': json.loads(self.hidden_fields or '[]'),
        }

    def __repr__(self):
        return f'<CanvasNode {self.table_name}>'


class TableRelationship(BaseModel):
    """A join relationship between two tables on a canvas."""
    __tablename__ = 'table_relationships'

    model_id = db.Column(db.Integer, db.ForeignKey('join_models.id'), nullable=False)
    source_table = db.Column(db.String(100), nullable=False)
    source_field = db.Column(db.String(100), nullable=False)
    target_table = db.Column(db.String(100), nullable=False)
    target_field = db.Column(db.String(100), nullable=False)
    join_type = db.Column(db.String(30), default='INNER JOIN')  # INNER, LEFT, RIGHT, FULL, CROSS
    alias = db.Column(db.String(100))
    description = db.Column(db.Text)
    sql_expression = db.Column(db.Text)
    additional_conditions = db.Column(db.Text)
    is_enabled = db.Column(db.Boolean, default=True)
    color = db.Column(db.String(20), default='#6366f1')
    line_style = db.Column(db.String(20), default='curved')  # curved, straight, orthogonal

    def to_dict(self):
        return {
            'id': self.id,
            'model_id': self.model_id,
            'source_table': self.source_table,
            'source_field': self.source_field,
            'target_table': self.target_table,
            'target_field': self.target_field,
            'join_type': self.join_type,
            'alias': self.alias,
            'description': self.description,
            'sql_expression': self.sql_expression,
            'additional_conditions': self.additional_conditions,
            'is_enabled': self.is_enabled,
            'color': self.color,
            'line_style': self.line_style,
        }

    def __repr__(self):
        return f'<TableRelationship {self.source_table}.{self.source_field} -> {self.target_table}.{self.target_field}>'
