from app.models.base import BaseModel
from app.extensions import db

class ServiceNowConnection(BaseModel):
    __tablename__ = 'servicenow_connections'
    
    name = db.Column(db.String(100), nullable=False, unique=True)
    instance_url = db.Column(db.String(255), nullable=False)
    username = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(255), nullable=False) # In a real scenario, this must be encrypted
    api_version = db.Column(db.String(50), default='v2')
    is_active = db.Column(db.Boolean, default=True)
    is_default = db.Column(db.Boolean, default=False)
    
    def __repr__(self):
        return f'<ServiceNowConnection {self.name}>'
